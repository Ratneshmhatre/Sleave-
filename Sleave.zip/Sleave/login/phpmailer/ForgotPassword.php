<?php

$to = "fmistry42@gmail.com";
$subject = "Test mail";
$message = "Reset password"
$from = "mohammedfurkanmistry@gmail.com";
$headers = "From: $from";
if(mail($to , $subject , $message , $headers)){
    echo "mail sent";
}else{
    echo "Mail not sent";
}

?>

